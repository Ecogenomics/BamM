#!/usr/bin/env python


if __name__ == "__main__":

    try:
        import tables
        print "Tables version: %s" % tables.__version__
        print "Location: %s" % tables.__file__
    except ImportError:
        print "Error importing pytables"

    try:
        import numpy
        print "Numpy version: %s" % numpy.__version__
        print "Location: %s" % numpy.__file__
    except ImportError:
        print "Error importing numpy"

    try:
        import scipy
        print "Scipy version: %s" %  scipy.__version__
        print "Location: %s" % scipy.__file__
    except ImportError:
        print "Error importing scipy"

    try:
        import matplotlib
        print "MPL version: %s" %  matplotlib.__version__
        print "Location: %s" % matplotlib.__file__
    except ImportError:
        print "Error importing matplotlib"

    import platform
    import sys
    print platform.system(), platform.release()
    print(sys.version)
    print(sys.path)